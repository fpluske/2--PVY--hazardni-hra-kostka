const imgKostka = document.getElementsByTagName("img")[0];
const captionKostka = document.querySelector("figcaption");
const statistika = document.getElementById("statistika");
const btnHrej = document.querySelector(".btn.btn-danger");
let hod;
let hody = [];

let interval;
let haziSe = false;

btnHrej.addEventListener("click", function () {
    if (!haziSe) {
        btnHrej.textContent = "Stop";
        
        interval = setInterval(() => {
            hod = Math.ceil(Math.random() * 6);
            captionKostka.innerHTML = `<h1 class="badge rounded-pill bg-danger">${hod}</h1>`;
            imgKostka.src = `img/kostka${hod}.png`;
        }, 40);
    } else {
        clearInterval(interval);
        hody.push(hod);
        btnHrej.textContent = "Hrej";
        statistika.innerHTML = stat();
    }

    haziSe = !haziSe;

    // hod = Math.ceil(Math.random() * 6);
    // captionKostka.innerHTML = `<h1 class="badge rounded-pill bg-danger">${hod}</h1>`;
    // imgKostka.src = `img/kostka${hod}.png`;
    // hody.push(hod);
    // console.log(hody);
    // console.log(maxHody());
    // statistika.innerHTML = stat();
});

function sumaHodu() {
    let suma = 0;
    for (let i = 0; i < hody.length; i++) {
        suma += hody[i];
    }

    return suma;
}

function minHody() {
    let min = 6;
    for (let i = 0; i < hody.length; i++) {
        if (hody[i] < min) min = hody[i];
    }

    return min;    
}

function maxHody() {
    let max = 1;
    hody.forEach(function(h) {
        if (max < h) max = h;
    });
    return max;    
}

function stat() {
    let vystup = '<h3>Statistika</h3>';
    vystup += `<p>Počet hodů: ${hody.length}</p>`;
    vystup += `<p>Součet hodů: ${sumaHodu()}</p>`;
    vystup += `<p>Průměr hodů: ${(sumaHodu() / hody.length).toFixed(2)}</p>`;
    vystup += `<p>Minimum: ${minHody()}</p>`;
    vystup += `<p>Maximum: ${maxHody()}</p>`;    
    return vystup;
}